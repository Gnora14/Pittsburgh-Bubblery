<?php
require_once('inc/db_connect.php');

if(session_status() === PHP_SESSION_NONE) session_start();


// Get all materials
$materialsQuery = 'SELECT * FROM materials
                       ORDER BY materialID';
$statement = $db->prepare($materialsQuery);
$statement->execute();
$fetchMaterials = $statement->fetchAll();
$statement->closeCursor();
?>

<!DOCTYPE html>
<html>


<head>
	<title>Bubble System - Add Material</title>
	<?php echo '<link rel="stylesheet" type="text/css" href="style.css"></head>'; ?>
</head>

<header>
	<p>Add New Material</p>
	<a class="homeButton" href="index.php"><img src="img/home_image.png"/></a>
</header>

	<table>
	<tr>
		<th>Material Name</th>
		<th>Quantity (Ounces)</th>
	</tr>
		<tr>
			<form action="materialAdd.php" method="get" id="add_material_form">
				<td><input type="text" name="matName"?></td>
				<td><input type="text" name="matQuan"?></td>
				<td><input type="submit" value="Add Material"></td>
			</form>				
		</tr>
	</table>
<body>
</body>

<footer>
	<ul>
		<li><a href="materials.php">Cancel</a></li>
		<!-- <li><a href="####.php">Add Material</a></li> -->
	</ul>
</footer>



</html>
