<?php
require_once('inc/db_connect.php');

if(session_status() === PHP_SESSION_NONE) session_start();

$numberOfMats = filter_input(INPUT_GET, 'num_mats');


// Get all materials
$materialsQuery = 'SELECT * FROM materials
                       ORDER BY materialID';
$statement = $db->prepare($materialsQuery);
$statement->execute();
$fetchMaterials = $statement->fetchAll();
$statement->closeCursor();

?>

<!DOCTYPE html>
<html>


<head>
	<title>Bubble System - Add Recipe</title>
	<?php echo '<link rel="stylesheet" type="text/css" href="style.css"></head>'; ?>
</head>

<header>
	<p>Add New Recipe</p>
	<a class="homeButton" href="index.php"><img src="img/home_image.png"/></a>
</header>

	<form action="recipeAddForm.php" method="get" id="num_mat_form" class="finish_batch">

		<td>Enter the number of materials:</td>
		<td><input type="text" name="num_mats"></td>

		<div><input type="submit" value="Continue"></div>
	</form> 


<?php
	// Validate inputs
	if($numberOfMats != null){
?>

	<table>
	<tr>
		<th>Recipe Name</th>
		<th>Materials</th>
		<th>Quantity Used</th>
	</tr>


	<form action="recipesAddForm.php" method="get" id="add_recipe_form">
	
	<?php
		for ($x = 0; $x < $numberOfMats; $x++) { ?>
			<tr>
				<?php if($x < 1){ //makes it so that only 1 name stop appears?>
					<td><input type="text" name="recipeName"?></td>
				<?php }
				else { //fills the remaining name spots so the other rows stay in place?>
					<td></td>
				<?php } ?>
				
				<td><select name="<?php echo "Mat".$x + 1 ;?>">
					<?php foreach ($fetchMaterials as $mats) : ?>
						<option value="<?php echo $mats['materialID']; ?>">
							<?php echo $mats['materialName']; ?>
						</option>
					<?php endforeach; ?>
				</select></td>
				
				<td><input type="text" name="<?php echo "Quan".$x + 1 ;?>" ></td>			
			</tr>
		<?php }	?>
		
		<td><input type="submit" value="Add Recipe"></td>
	</table>
		
	<?php } ?>
		
	</form>		
	
	
<body>
</body>

<footer>
	<ul>
		<li><a href="recipes.php">Cancel</a></li>
		<!-- <li><a href="####.php">Add Recipe</a></li> -->
	</ul>
</footer>



</html>
