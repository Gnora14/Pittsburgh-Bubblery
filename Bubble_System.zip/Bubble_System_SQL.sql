
-- create and select the database
DROP DATABASE IF EXISTS Bubble_System_SQL;
CREATE DATABASE Bubble_System_SQL;
USE Bubble_System_SQL;

-- create the tables for the database
CREATE TABLE materials (
  materialID        INT           NOT NULL   AUTO_INCREMENT,
  materialName      VARCHAR(64)   NOT NULL,
  materialQuantity  FLOAT  		  NOT NULL,
  PRIMARY KEY (materialID)
);


CREATE TABLE recipe (
  recipeID         	INT            	NOT NULL   AUTO_INCREMENT,
  recipeName        VARCHAR(64)    	NOT NULL,
  materialName      VARCHAR(64)     NOT NULL,
  materialNeeded    FLOAT		   	NOT NULL,
  PRIMARY KEY (recipeID)
);


  
-- Insert data into the tables
INSERT INTO materials (materialID, materialName, materialQuantity) VALUES
(1, 'aldeholic acid', 2.2),
(2, 'cinnamic acid', 3.3),
(3, 'Antioxidant', 4.5),
(4, 'D Panthenol', 25.7),
(5, 'alcohol', 5.34),
(6, 'Ethyl', 4.1),
(7, 'isopropyl chlorobutanol', 5.3),
(8, 'Cresol', 14.8),
(9, 'phenol', 7.6),
(10, 'cinnamic acid', 5.2),
(11, 'Coriander', 1.5),
(12, 'Caraway', 8.9),
(13, 'Anise', 6.1);


-- Insert data into the tables
INSERT INTO recipe (recipeID, recipeName, materialName, materialNeeded) VALUES
(1, 'Soap', 'dust', 1.2),
(2, 'Shampoo', 'squish', 2.3);





-- Create a user named mgs_user
GRANT SELECT, INSERT, UPDATE, DELETE
ON *
TO mgs_user@localhost
IDENTIFIED BY 'pa55word';
