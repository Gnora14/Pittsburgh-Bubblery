
-- create and select the database
DROP DATABASE IF EXISTS Bubble_System_SQL;
CREATE DATABASE Bubble_System_SQL;
USE Bubble_System_SQL;

-- create the tables for the database
CREATE TABLE materials (
  materialID        INT           NOT NULL   AUTO_INCREMENT,
  materialName      VARCHAR(64)   NOT NULL,
  materialQuantity  FLOAT  		  NOT NULL,
  materialUnit      VARCHAR(64)   NOT NULL,
  PRIMARY KEY (materialID)
);


CREATE TABLE recipe (
  recipeID         	INT            	NOT NULL   AUTO_INCREMENT,
  recipeName        VARCHAR(64)    	NOT NULL,
  recipeDESC        VARCHAR(64)     NOT NULL,
  PRIMARY KEY (recipeID)
);

CREATE TABLE recipeLine (
  recipe_Line_Num   	INT            	NOT NULL   AUTO_INCREMENT,
  recipeID         		INT            	NOT NULL,
  materialID        	INT             NOT NULL,
  recipe_Line_Needed    FLOAT		   	NOT NULL,
  PRIMARY KEY (recipe_Line_Num),
  FOREIGN KEY (recipeID) REFERENCES recipe(recipeID),
  FOREIGN KEY (materialID) REFERENCES materials(materialID)
);


  
-- Insert data into the table
INSERT INTO materials (materialID, materialName, materialQuantity) VALUES
(1, 'Aldeholic acid', 2.2),
(2, 'Cinnamic acid', 3.3),
(3, 'Antioxidant', 4.5),
(4, 'D Panthenol', 25.7),
(5, 'Alcohol', 5.34),
(6, 'Ethyl', 4.1),
(7, 'Isopropyl chlorobutanol', 5.3),
(8, 'Cresol', 14.8),
(9, 'Phenol', 7.6),
(10, 'Cinnamic acid', 5.2),
(11, 'Coriander', 1.5),
(12, 'Caraway', 8.9),
(13, 'Anise', 6.1);


-- Insert data into the table
INSERT INTO recipe (recipeID, recipeName, recipeDESC) VALUES
(1, 'Soap', 'dust'),
(2, 'Shampoo', 'squish');


-- Insert data into the table
INSERT INTO recipeLine (recipe_Line_Num, recipeID, materialID, recipe_Line_Needed) VALUES
(1,1,1, 1.5),
(2,1,2, 2.5),
(3,1,3, 3.5),
(4,1,4, 4.5),
(5,1,5, 5.5),
(6,1,6, 6.5),
(7,2,7, 7.5),
(8,2,8, 8.5),
(9,2,9, 9.5);




-- Create a user named mgs_user
GRANT SELECT, INSERT, UPDATE, DELETE
ON *
TO mgs_user@localhost
IDENTIFIED BY 'pa55word';
