<?php
require_once('inc/db_connect.php');

$materialID = filter_input(INPUT_GET, 'matID');
$materialName = filter_input(INPUT_GET, 'matName');
$materialQuan = filter_input(INPUT_GET, 'matQuan');

if(session_status() === PHP_SESSION_NONE) session_start();

// Get all materials
$materialsQuery = 'SELECT * FROM materials
                       ORDER BY materialID';
$statement = $db->prepare($materialsQuery);
$statement->execute();
$fetchMaterials = $statement->fetchAll();
$statement->closeCursor();
?>

<!DOCTYPE html>
<html>


<head>
	<title>Bubble System - Material Update</title>
	<?php echo '<link rel="stylesheet" type="text/css" href="style.css"></head>'; ?>
</head>

<header>
	<div class="title">
		<p>Material Inventory</p>
		<img src="img/mat_image.png" alt="material">
		<a class="homeButton" href="index.php"><img src="img/home_image.png"/></a>
	</div>
</header>

<body>

<div class="content">
	<table>
	<tr>
		<th>Material Name</th>
		<th>Quantity (Ounces)</th>
	</tr>
		<?php foreach ($fetchMaterials as $material){ ?>

			<?php if($material['materialID'] == $materialID){ ?>
				<form action="materialUpdate.php" method="get" id="update_material_form">
					<td><input type="text" name="matName" value="<?php echo $materialName;?>"></td>
					<td><input type="text" name="matQuan" value="<?php echo $materialQuan;?>"></td>
					<input type="hidden" name="matID" value="<?php echo $materialID; ?>">
					<td><input type="submit" value="Update Material"></td>
				</form>
			<?php } 

			
			else{ ?>
				<tr>
					<td><?php echo $material['materialName']; ?></td>
					<td><?php echo $material['materialQuantity']; ?></td>  
					
					<form action="materialUpdateForm.php" method="get" >
						<td><input type="submit" name="update_material" value="Update"></td>
						<input type="hidden" name="matID" value="<?php echo $material['materialID']; ?>">
						<input type="hidden" name="matName" value="<?php echo $material['materialName']; ?>">
						<input type="hidden" name="matQuan" value="<?php echo $material['materialQuantity']; ?>">
					</form>
					
					<form action="materialDelete.php" method="get" >
						<td><input type="submit" name="delete_material" value="Delete"></td>
						<input type="hidden" name="matID" value="<?php echo $material['materialID']; ?>">
						<input type="hidden" name="matName" value="<?php echo $material['materialName']; ?>">
					</form>					
				</tr>
			<?php } } ?>
	</table>
</div>

<footer>
	<ul>
		<li><a href="recipes.php">Go To Recipes</a></li>
		<li><a href="materialAddForm.php">Add New Material</a></li>

	</ul>
</footer>
	
</body>





</html>
