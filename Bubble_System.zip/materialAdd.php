<?php
require('inc/db_connect.php');
// Get the event data
$materialName = filter_input(INPUT_GET, 'matName');
$materialQuantity = filter_input(INPUT_GET, 'matQuan');

// Validate inputs
if($materialName === null || $materialQuantity === null){
    echo "Error; could not retreive all values";
}
else{
    // add the material to the database  
    $matAddQuery = 'INSERT INTO materials
					(materialName, materialQuantity)
					VALUES
					(:name, :quan)';
				 
    $statement = $db->prepare($matAddQuery);
	$statement->bindValue(':name', $materialName);
    $statement->bindValue(':quan', $materialQuantity);
    $statement->execute();
    $statement->closeCursor();

    // Display the material page
    include('index.php');
}



?>
