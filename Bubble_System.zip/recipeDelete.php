<?php
require('inc/db_connect.php');
// Get the recipe data
$recipeID = filter_input(INPUT_GET, 'recID');
$recipeName = filter_input(INPUT_GET, 'recName');

// Validate inputs
if ($recipeID === null) {
    echo  "Error; could not retreive item ID";
}
else{
    // delete the recipe from the database  
    $recipeDeleteQuery = 'DELETE FROM recipe WHERE recipeID=:recID';
	
    $statement = $db->prepare($recipeDeleteQuery);
	$statement->bindValue(':recID', $recipeID);
    $statement->execute();
    $statement->closeCursor();

    // Display the recipe page
    include('recipes.php');
	echo "<p style='color:red;
			margin-left: 20px;
			font-family: Gotham, Helvetica, Arial, sans-serif;
	'>".$recipeName."'s recipe has been deleted"."</p>";
}

?>

