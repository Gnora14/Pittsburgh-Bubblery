<?php
require_once('inc/db_connect.php');

if(session_status() === PHP_SESSION_NONE) session_start();

// Get all recipes
$recipesQuery = 'SELECT * FROM recipe
                       ORDER BY recipeID';
$statement = $db->prepare($recipesQuery);
$statement->execute();
$fetchRecipes = $statement->fetchAll();
$statement->closeCursor();
?>

<!DOCTYPE html>
<html>


<head>
	<title>Bubble System - Recipes</title>
	<?php echo '<link rel="stylesheet" type="text/css" href="styleSheet.css"></head>'; ?>
</head>

<header>
	<p>Current Recipes</p>
	<img src="img/rec_image.png" alt="material">
</header>

<body>
	<table>
	<tr>
		<th>Recipe Name</th>
		<th>Materials</th>
		<th>Quantity (Ounces)</th>
	</tr>
		<?php foreach ($fetchRecipes as $recipe) : ?>
			<tr>
				<!--The name, materials, and quantity-->
				<td><?php echo $recipe['recipeName']; ?></td>				
				<td><?php echo $recipe['materialName']; ?></td>
				<td><?php echo $recipe['materialNeeded']; ?></td>

				<!--The Buttons -->
				<form action="####.php" method="get" >
					<td><input type="submit" name="update_recipe" value="Update"></td>
				</form>	
				<form action="recipeDelete.php" method="get" >
					<td><input type="submit" name="delete_recipe" value="Delete"></td>
					<input type="hidden" name="recID" value="<?php echo $recipe['recipeID']; ?>">
					<input type="hidden" name="recName" value="<?php echo $recipe['recipeName']; ?>">
				</form>
				<form action="batch.php" method="get" >
					<td><input type="submit" name="new_batch" value="Create New Batch"></td>
					<input type="hidden" name="recName" value="<?php echo $recipe['recipeName']; ?>">
				</form>
			</tr>
		<?php endforeach; ?>
	</table>
</body>

<footer>
	<ul>
        <li><a href="nav.php">Navigation</a></li>
		<li><a href="index.php">Go To Inventory</a></li>
		<li><a href="recipeAddForm.php">Add New Recipe</a></li>

	</ul>
</footer>



</html>
