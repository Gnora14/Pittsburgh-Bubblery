<?php
require_once('inc/db_connect.php');

if(session_status() === PHP_SESSION_NONE) session_start();

// Get all materials
$materialsQuery = 'SELECT * FROM materials
                       ORDER BY materialID';
$statement = $db->prepare($materialsQuery);
$statement->execute();
$fetchMaterials = $statement->fetchAll();
$statement->closeCursor();
?>

<!DOCTYPE html>
<html>


<head>
	<title>Bubble System - Home</title>
	<?php echo '<link rel="stylesheet" type="text/css" href="style.css"></head>'; ?>
</head>

<header>
	<div class="title">
		<p>Home Page - Bubble System</p>
		<img src="img/home_image.png" alt="material">
	</div>
</header>

<body class="homeBody">

		<li class="homeLI1">
			<a class="homeA" href="materials.php">Material Inventory</a>
			<img class="homeIMG" src="img/mat_image.png" alt="material">
		</li>
		<li class="homeLI2">
			<a class="homeA" href="recipes.php">List of Recipes</a>
			<img class="homeIMG" src="img/rec_image.png" alt="material">
		</li>


</body>

<footer class="homeFooter">
</footer>



</html>
