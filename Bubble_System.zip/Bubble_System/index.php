<?php
require_once('inc/db_connect.php');

if(session_status() === PHP_SESSION_NONE) session_start();

// Get all materials
$materialsQuery = 'SELECT * FROM materials
                       ORDER BY materialID';
$statement = $db->prepare($materialsQuery);
$statement->execute();
$fetchMaterials = $statement->fetchAll();
$statement->closeCursor();
?>

<!DOCTYPE html>
<html>


<head>
	<title>Bubble System - Materials</title>
	<?php echo '<link rel="stylesheet" type="text/css" href="styleSheet.css">'; ?>
</head>

<header>
	<div class="title">
		<p>Material Inventory</p>
		<img src="img/mat_image.png" alt="material">
	</div>
</header>

<body>
	<table>
	<tr>
		<th>Material Name</th>
		<th>Quantity (Ounces)</th>
	</tr>
		<?php foreach ($fetchMaterials as $material) : ?>
			<tr>
				<td><?php echo $material['materialName']; ?></td>
				<td><?php echo $material['materialQuantity']; ?></td>  
				
				<form action="materialUpdateForm.php" method="get" >
					<td><input type="submit" name="update_material" value="Update"></td>
					<input type="hidden" name="matID" value="<?php echo $material['materialID']; ?>">
					<input type="hidden" name="matName" value="<?php echo $material['materialName']; ?>">
					<input type="hidden" name="matQuan" value="<?php echo $material['materialQuantity']; ?>">
				</form>
				<form action="materialDelete.php" method="get" >
					<td><input type="submit" name="delete_material" value="Delete"></td>
					<input type="hidden" name="matID" value="<?php echo $material['materialID']; ?>">
					<input type="hidden" name="matName" value="<?php echo $material['materialName']; ?>">
				</form>					
			</tr>
		<?php endforeach; ?>
	</table>
</body>

<footer>
	<ul>
        <li><a href="nav.php">Navigation</a></li>
		<li><a href="recipes.php">Go To Recipes</a></li>
		<li><a href="materialAddForm.php">Add New Material</a></li>

	</ul>
</footer>



</html>
