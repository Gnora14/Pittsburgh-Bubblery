<html>
<head>
    <?php echo '<link rel="stylesheet" type="text/css" href="styleSheet.css">'; ?>
</head>
<body>
<header>
    <p>Navigation</p>
    <img src="img/Menu_image.png" alt="Nav"/>
</header>
  
    <h1>Welcome!</h1>
    <ul>
		<li><a href="recipes.php">Go To Recipes</a></li>
		<li><a href="index.php">Go to Materials</a></li>
	</ul>
<footer>
</footer>
</body>
</html>