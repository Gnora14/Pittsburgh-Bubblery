<?php
require('inc/db_connect.php');
// Get the event data
$materialID = filter_input(INPUT_GET, 'matID');
$materialName = filter_input(INPUT_GET, 'matName');
$materialQuantity = filter_input(INPUT_GET, 'matQuan');

// Validate inputs
if($materialID === null || $materialName === null || $materialQuantity === null){
    echo "Error; could not retreive all values";
}
else{
    // update the material from the database  
	 $matUpdateQuery = 'UPDATE materials
                 SET materialName = :name, materialQuantity = :quan
				 WHERE materialID =:matID';
				 
    $statement = $db->prepare($matUpdateQuery);
	$statement->bindValue(':matID', $materialID);
	$statement->bindValue(':name', $materialName);
    $statement->bindValue(':quan', $materialQuantity);
    $statement->execute();
    $statement->closeCursor();

    // Display the material page
    include('index.php');
}



?>
