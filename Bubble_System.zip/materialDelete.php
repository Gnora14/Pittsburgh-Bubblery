<?php
require('inc/db_connect.php');
// Get the event data
$materialID = filter_input(INPUT_GET, 'matID');
$materialName = filter_input(INPUT_GET, 'matName');

// Validate inputs
if ($materialID === null) {
    echo  "Error; could not retreive item ID";
}
else{
    // delete the material from the database  
    $materialDeleteQuery = 'DELETE FROM materials WHERE materialID=:matID';
	
    $statement = $db->prepare($materialDeleteQuery);
	$statement->bindValue(':matID', $materialID);
    $statement->execute();
    $statement->closeCursor();

    // Display the Material page
    include('materials.php');
		echo "<p style='color:red;
			margin-left: 20px;
			font-family: Gotham, Helvetica, Arial, sans-serif;
	'>".$materialName." has been deleted"."</p>";
}

?>

