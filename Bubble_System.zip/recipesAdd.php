<?php
require('inc/db_connect.php');
// Get the event data
$recipeName = filter_input(INPUT_GET, 'recipeName');
$recipeDesc = filter_input(INPUT_GET, 'recipeDesc');


// Validate inputs
if($recipeName === null || $recipeDesc === null){
    echo "Error; could not retreive all values";
}
else{
    // add the material to the database  
    $recAddQuery = 'INSERT INTO recipe
					(recipeName,recipeDESC)
					VALUES
					(:name, :Desc)';
				 
    $statement = $db->prepare($recAddQuery);
	$statement->bindValue(':name', $recipeName);
	$statement->bindValue(':Desc', $recipeDesc);
    $statement->execute();
    $statement->closeCursor();

    // Display the material page
    include('recipes.php');
}



?>