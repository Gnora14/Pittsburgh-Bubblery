<?php
require_once('inc/db_connect.php');

if(session_status() === PHP_SESSION_NONE) session_start();


// Get all recipes
$recipesQuery = 'SELECT * FROM recipe
                       ORDER BY recipeID';
$statement = $db->prepare($recipesQuery);
$statement->execute();
$fetchRecipes = $statement->fetchAll();
$statement->closeCursor();
?>

<!DOCTYPE html>
<html>


<head>
	<title>Bubble System - Add Recipe</title>
	<?php echo '<link rel="stylesheet" type="text/css" href="style.css"></head>'; ?>
</head>

<header>
	<p>Add New Recipe</p>
	<a class="homeButton" href="index.php"><img src="img/home_image.png"/></a>
</header>

	<table>
	<tr>
		<th>Recipe Name</th>
		<th>Recipe Description</th>
	</tr>
		<tr>
			<form action="recipesAdd.php" method="get" id="add_recipe_form">
				<td><input type="text" name="recipeName"?></td>
				<td><input type="text" name="recipeDesc"?></td>
				<td><input type="submit" value="Add Recipe"></td>
			</form>
			
		</tr>

	</table>

<body>
</body>

<footer>
	<ul>
		<li><a href="recipes.php">Cancel</a></li>
		<!-- <li><a href="####.php">Add Recipe</a></li> -->
	</ul>
</footer>



</html>
