
-- create and select the database
DROP DATABASE IF EXISTS Bubble_System_SQL;
CREATE DATABASE Bubble_System_SQL;
USE Bubble_System_SQL;

-- create the tables for the database
CREATE TABLE materials (
  materialID        INT           NOT NULL   AUTO_INCREMENT,
  materialName      VARCHAR(64)   NOT NULL,
  materialQuantity  FLOAT  		  NOT NULL,
  materialUnit      VARCHAR(64)   NOT NULL,
  PRIMARY KEY (materialID)
);


CREATE TABLE recipe (
  recipeID         	INT            	NOT NULL   AUTO_INCREMENT,
  recipeName        VARCHAR(64)    	NOT NULL,
  recipeDESC        VARCHAR(64)     NOT NULL,
  PRIMARY KEY (recipeID)
);

CREATE TABLE recipeLine (
  recipe_Line_Num   	INT            	NOT NULL   AUTO_INCREMENT,
  recipeID         		INT            	NOT NULL,
  materialID        	INT             NOT NULL,
  recipe_Line_Needed    FLOAT		   	NOT NULL,
  PRIMARY KEY (recipe_Line_Num),
  FOREIGN KEY (recipeID) REFERENCES recipe(recipeID),
  FOREIGN KEY (materialID) REFERENCES materials(materialID)
);


  
-- Insert data into the tables
INSERT INTO materials (materialID, materialName, materialQuantity, materialUnit) VALUES
(1, 'aldeholic acid', 2.2,'LB'),
(2, 'cinnamic acid', 3.3,'LB'),
(3, 'Antioxidant', 4.5,'LB'),
(4, 'D Panthenol', 25.7,'LB'),
(5, 'alcohol', 5.34,'LB'),
(6, 'Ethyl', 4.1,'LB'),
(7, 'isopropyl chlorobutanol', 5.3,'LB'),
(8, 'Cresol', 14.8,'LB'),
(9, 'phenol', 7.6,'LB'),
(10, 'cinnamic acid', 5.2,'LB'),
(11, 'Coriander', 1.5,'LB'),
(12, 'Caraway', 8.9,'LB'),
(13, 'Anise', 6.1,'LB');


-- Insert data into the tables
INSERT INTO recipe (recipeID, recipeName, recipeDESC) VALUES
(1, 'Soap', 'dust'),
(2, 'Shampoo', 'squish');

INSERT INTO recipeLine (recipe_Line_Num, recipeID, materialID, recipe_Line_Needed) VALUES
(1,1,2, 2.5),
(2,1,4, 2.5);






-- Create a user named mgs_user
GRANT SELECT, INSERT, UPDATE, DELETE
ON *
TO mgs_user@localhost
IDENTIFIED BY 'pa55word';
