<?php
require_once('inc/db_connect.php');

$recipeName = filter_input(INPUT_GET, 'recName');
$recID = filter_input(INPUT_GET, 'recID');
$matID = filter_input(INPUT_GET, 'matID');
if(session_status() === PHP_SESSION_NONE) session_start();

// Get all materials


$recipesLineQuery = 'SELECT * FROM recipeLine
							WHERE recipeID =:recID' ;
$statement = $db->prepare($recipesLineQuery);
$statement->bindValue('recID', $recID);
$statement->execute();
$fetchRecipes = $statement->fetchAll();
$statement->closeCursor();

?>

<!DOCTYPE html>
<html>


<head>
	<title>Bubble System - Batch</title>
	<?php echo '<link rel="stylesheet" type="text/css" href="style.css"></head>'; ?>
</head>

<header>
	<div class="title">
		<p>Batch Making</p>
		<img src="img/batch_image.png" alt="material">
		<a class="homeButton" href="index.php"><img src="img/home_image.png"/></a>
	</div>
</header>

<body>
	<h1>Batch in Progress: <?php echo $recipeName ?></h1>	

	<table>
	<tr>
		<th>Material Code</th>
		<th>Quantity (Ounces)</th>
	</tr>
		<?php foreach ($fetchRecipes as $recipe) : ?>
			<tr>
				<td><?php echo $recipe['materialID']; ?></td>	
				<td><?php echo $recipe['recipe_Line_Needed']; ?></td>			
			</tr>
		<?php endforeach; ?>
	</table>
	
	
	<form action="recipes.php" method="post" id="choose_recipe_form" class="finish_batch">

		<td>How Many Items:</td>
		<td><input type="text" name="eve_name"></td>

		<div><input type="submit" value="Finish Batch"></div>
	</form> 

</body>

<footer>
	<ul>
		<li><a href="recipes.php">Cancel</a></li>
		<!-- <li><a href="####.php">Failed Batch</a></li> -->
		<!-- <li><a href="####.php">Successful Batch</a></li> -->
	</ul>
</footer>



</html>
