<?php
require('inc/db_connect.php');
// Get the event data
$recipeID = filter_input(INPUT_GET, 'recipeID');
$MaterialID = filter_input(INPUT_GET, 'MaterialID');
$Quan = filter_input(INPUT_GET, 'Quan');

// Validate inputs
if($recipeID === null || $MaterialID === null || $Quan === Null){
    echo "Error; could not retreive all values";
}
else{
    // add the material to the database  
    $recAddQuery = 'INSERT INTO recipeLine
					(recipeID,materialID,recipe_Line_Needed)
					VALUES
					(:recipeID, :MaterialID, :Quan)';
				 
    $statement = $db->prepare($recAddQuery);
	$statement->bindValue(':recipeID', $recipeID);
	$statement->bindValue(':MaterialID', $MaterialID);
	$statement->bindValue(':Quan', $Quan);
    $statement->execute();
    $statement->closeCursor();

    // Display the material page
    include('recipes.php');
}



?>